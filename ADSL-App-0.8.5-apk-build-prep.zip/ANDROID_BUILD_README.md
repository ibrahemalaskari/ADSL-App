# APK build workflow (initial packaging setup)

GitHub Actions packages the web UI into a debug APK.

Trigger: push to main touching core/www/config/package/workflow, or manually via Actions -> Build Android APK -> Run workflow.

Artifact: ADSL-App-debug-apk.

Important limitation: this build is a WebView package. The existing project depends on the Termux Node bridge and Node SQLite. These are not ported to native Android in this scaffold, so the resulting APK is a packaging/build validation step and is NOT yet a fully standalone functional Android replacement. Native TCP transport and native database implementation remain required.
